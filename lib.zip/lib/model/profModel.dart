class ProfModel {
  String education;
  String year;
  String grade;
  String experience;
  String designation;
  String domain;

  ProfModel(this.education, this.year, this.grade, this.experience,
      this.designation, this.domain);
}
