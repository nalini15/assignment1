class AddressModel {
  int value;
  String name;

  AddressModel(this.value, this.name);
}
