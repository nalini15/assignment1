class BasicModel {
  String fname;
  String lname;
  String contact;
  String email;
  String password;
  String cpassword;

  BasicModel(
      {this.fname,
      this.lname,
      this.contact,
      this.email,
      this.password,
      this.cpassword});
}
