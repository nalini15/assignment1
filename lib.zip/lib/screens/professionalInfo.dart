import 'dart:io';

import 'package:assignment1/functions/widgetFunction.dart';
import 'package:assignment1/model/profModel.dart';
import 'package:assignment1/navigations/navigationAnimation.dart';
import 'package:assignment1/screens/addressInfo.dart';
import 'package:assignment1/screens/basicInfo.dart';
import 'package:assignment1/style/colors.dart';
import 'package:flutter/material.dart';

class ProfessionalInfo extends StatefulWidget {
  @override
  _ProfessionalInfoState createState() => _ProfessionalInfoState();
}

class _ProfessionalInfoState extends State<ProfessionalInfo> {
  final GlobalKey<ScaffoldState> _scaffoldkey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  Map<String, dynamic> formData = {
    "grade": "",
    "experience": "",
  };

  List<String> education =
      // ['USA', 'India'];
      ['Post Graduate', 'Post Graduate', 'HSC/Diploma', 'SSC', 'Required'];
  List<String> yearOfPassing =
      //['New Delhi', 'Bihar', 'Rajasthan'];
      ['2021', '2020', '2019'];
  List<String> usaProvince = ['Texas', 'Florida', 'California'];

  List<String> provinces = [];
  String selectedCountry;
  String selectedProvince;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldkey,
      appBar: AppBar(
        leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: textColor,
            ),
            onPressed: () {}),
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Your Info',
          style: TextStyle(
              fontWeight: FontWeight.bold, color: textColor, fontSize: 25),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        top: Platform.isIOS ? false : true,
        bottom: Platform.isIOS ? false : true,
        child: Container(
          width: double.infinity,
          height: double.infinity,
          //alignment: Alignment.center,
          child: SingleChildScrollView(
            child: Column(
              children: [
                buildSizedBoxHeight(30),
                Container(
                    width: MediaQuery.of(context).size.width * 0.8,
                    child: Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Educational Info',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20),
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Education*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: DropdownButton<String>(
                              hint: Padding(
                                padding: const EdgeInsets.all(15.0),
                                child: Text('Select your qualification'),
                              ),
                              value: selectedCountry,
                              isExpanded: true,
                              items: education.map((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                              // onChanged: (country) {
                              //   if (country == 'USA') {
                              //     provinces = usaProvince;
                              //   } else if (country == 'India') {
                              //     provinces = yearOfPassing;
                              //   } else {
                              //     provinces = [];
                              //   }
                              //   setState(() {
                              //     selectedProvince = null;
                              //     selectedCountry = country;
                              //   });
                              // },
                            ),
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Year of passing*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: DropdownButton<String>(
                              hint: Padding(
                                padding: const EdgeInsets.all(15.0),
                                child: Text('Enter year of passing'),
                              ),
                              value: selectedProvince,
                              isExpanded: true,
                              items: provinces.map((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                              // onChanged: (province) {
                              //   setState(() {
                              //     selectedProvince = province;
                              //   });
                              // },
                            ),
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Grade*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: TextFormField(
                                autocorrect: true,
                                style: TextStyle(fontSize: 15),
                                validator: (value) {
                                  if (value.trimRight().trimLeft().isEmpty) {
                                    return 'Please enter your grade or percentage';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  formData['grade'] =
                                      value.trimLeft().trimRight();
                                },
                                decoration: InputDecoration(
                                  errorStyle: TextStyle(
                                      // color: whiteTextColor,
                                      ),
                                  hintText: 'Enter your Grade or Percentage',
                                  hintStyle: TextStyle(color: textColor1),
                                  contentPadding: EdgeInsets.fromLTRB(
                                      20.0, 15.0, 10.0, 15.0),
                                  isDense: true,
                                  // hintStyle:
                                  //     normalStyle.copyWith(color: Colors.white),
                                  // enabledBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: Colors.white),
                                  // ),
                                  // focusedBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: whiteTextColor),
                                  // ),
                                )),
                          ),
                          buildSizedBoxHeight(10),
                          Divider(
                            thickness: 2,
                          ),
                          buildSizedBoxHeight(10),
                          Text(
                            'Professional Info',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20),
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Experience*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: TextFormField(
                                autocorrect: true,
                                style: TextStyle(fontSize: 15),
                                validator: (value) {
                                  if (value.trimRight().trimLeft().isEmpty) {
                                    return 'Please enter your experience';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  formData['experience'] =
                                      value.trimLeft().trimRight();
                                },
                                decoration: InputDecoration(
                                  errorStyle: TextStyle(
                                      // color: whiteTextColor,
                                      ),
                                  hintText: 'Enter the years of experience',
                                  hintStyle: TextStyle(color: textColor1),
                                  contentPadding: EdgeInsets.fromLTRB(
                                      20.0, 15.0, 10.0, 15.0),
                                  isDense: true,
                                  // hintStyle:
                                  //     normalStyle.copyWith(color: Colors.white),
                                  // enabledBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: Colors.white),
                                  // ),
                                  // focusedBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: whiteTextColor),
                                  // ),
                                )),
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Designation*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: DropdownButton<String>(
                              hint: Padding(
                                padding: const EdgeInsets.all(15.0),
                                child: Text('Select designation'),
                              ),

                              value: selectedCountry,
                              isExpanded: true,
                              items: education.map((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                              // onChanged: (country) {
                              //   if (country == 'USA') {
                              //     provinces = usaProvince;
                              //   } else if (country == 'India') {
                              //     provinces = yearOfPassing;
                              //   } else {
                              //     provinces = [];
                              //   }
                              //   setState(() {
                              //     selectedProvince = null;
                              //     selectedCountry = country;
                              //   });
                              // },
                            ),
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Domain*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: DropdownButton<String>(
                              hint: Padding(
                                padding: const EdgeInsets.all(15.0),
                                child: Text('Select your domain'),
                              ),
                              value: selectedCountry,
                              isExpanded: true,
                              items: education.map((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                              // onChanged: (country) {
                              //   if (country == 'USA') {
                              //     provinces = usaProvince;
                              //   } else if (country == 'India') {
                              //     provinces = yearOfPassing;
                              //   } else {
                              //     provinces = [];
                              //   }
                              //   setState(() {
                              //     selectedProvince = null;
                              //     selectedCountry = country;
                              //   });
                              // },
                            ),
                          ),
                        ],
                      ),
                    )),
                buildSizedBoxHeight(20),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.only(left: 20, right: 20),
                        // width: 20,
                        child: FlatButton(
                            onPressed: () {
                              Navigator.pushReplacement(
                                  context, FadeNavigation(widget: BasicInfo()));
                            },
                            color: buttonCOlor,
                            child: Padding(
                                padding: EdgeInsets.all(10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Text('Previous',
                                        style: TextStyle(
                                          color: Colors.white,
                                        )),
                                  ],
                                ))),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.only(left: 20, right: 20),
                        // width: 20,
                        child: FlatButton(
                            onPressed: () {
                              Navigator.pushReplacement(context,
                                  FadeNavigation(widget: AddressInfo()));
                            },
                            color: buttonCOlor,
                            child: Padding(
                                padding: EdgeInsets.all(10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Text('Next',
                                        style: TextStyle(
                                          color: Colors.white,
                                        )),
                                  ],
                                ))),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
