import 'dart:io';

import 'package:assignment1/functions/widgetFunction.dart';
import 'package:assignment1/navigations/navigationAnimation.dart';
import 'package:assignment1/screens/professionalInfo.dart';
import 'package:assignment1/style/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class BasicInfo extends StatefulWidget {
  @override
  _BasicInfoState createState() => _BasicInfoState();
}

class _BasicInfoState extends State<BasicInfo> {
  final GlobalKey<ScaffoldState> _scaffoldkey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  Map<String, dynamic> formData = {
    "fname": "",
    "lname": "",
    "number": "",
    "email": "",
    "password": ""
  };
  bool _showPassword = false;
  int _groupValue = -1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldkey,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Register',
          style: TextStyle(
              fontWeight: FontWeight.bold, color: textColor, fontSize: 25),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        top: Platform.isIOS ? false : true,
        bottom: Platform.isIOS ? false : true,
        child: Container(
          width: double.infinity,
          height: double.infinity,
          alignment: Alignment.center,
          child: SingleChildScrollView(
            child: Center(
              child: Column(
                // mainAxisAlignment: MainAxisAlignment.center,
                // crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Stack(
                    children: <Widget>[
                      CircleAvatar(
                        radius: 51,
                        backgroundColor: textColor,
                        child: ClipOval(
                          child: Image.asset(
                            'assets/images/user.jpg',
                            height: 100,
                            width: 100,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Positioned(
                          bottom: 1,
                          right: 1,
                          child: Container(
                            height: 30,
                            width: 30,
                            child: Icon(
                              Icons.create_rounded,
                              color: Colors.black,
                            ),
                            decoration: BoxDecoration(
                                color: Colors.transparent,
                                border: Border.all(color: textColor),
                                borderRadius: BorderRadius.all(
                                  Radius.circular(20),
                                )),
                          ))
                    ],
                  ),
                  //  buildSizedBoxHeight(5),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.8,
                    child: Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'First Name*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: TextFormField(
                                autocorrect: true,
                                style: TextStyle(fontSize: 15),
                                inputFormatters: [
                                  FilteringTextInputFormatter.allow(
                                      RegExp('[a-zA-Z]')),
                                ],
                                validator: (value) {
                                  if (value.trimRight().trimLeft().isEmpty) {
                                    return 'Please enter your name';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  formData['fname'] =
                                      value.trimLeft().trimRight();
                                },
                                decoration: InputDecoration(
                                  prefixIcon: Icon(
                                    Icons.person,
                                    color: buttonCOlor,
                                  ),
                                  errorStyle: TextStyle(
                                      // color: whiteTextColor,
                                      ),
                                  hintText: 'Enter your first name',
                                  hintStyle: TextStyle(color: textColor1),
                                  contentPadding: EdgeInsets.fromLTRB(
                                      20.0, 15.0, 10.0, 15.0),
                                  isDense: true,
                                  // hintStyle:
                                  //     normalStyle.copyWith(color: Colors.white),
                                  // enabledBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: Colors.white),
                                  // ),
                                  // focusedBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: whiteTextColor),
                                  // ),
                                )),
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Last Name*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: TextFormField(
                                autocorrect: true,
                                style: TextStyle(fontSize: 15),
                                inputFormatters: [
                                  FilteringTextInputFormatter.allow(
                                      RegExp('[a-zA-Z]')),
                                ],
                                validator: (value) {
                                  if (value.trimRight().trimLeft().isEmpty) {
                                    return 'Please enter your last name';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  formData['lname'] =
                                      value.trimLeft().trimRight();
                                },
                                decoration: InputDecoration(
                                  prefixIcon: Icon(
                                    Icons.person,
                                    color: buttonCOlor,
                                  ),
                                  errorStyle: TextStyle(
                                      // color: whiteTextColor,
                                      ),
                                  hintText: 'Enter your last name',
                                  hintStyle: TextStyle(color: textColor1),
                                  contentPadding: EdgeInsets.fromLTRB(
                                      20.0, 15.0, 20.0, 15.0),
                                  isDense: true,
                                  // hintStyle:
                                  //     normalStyle.copyWith(color: Colors.white),
                                  // enabledBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: Colors.white),
                                  // ),
                                  // focusedBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: whiteTextColor),
                                  // ),
                                )),
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Phone Number*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: TextFormField(
                                autocorrect: true,
                                style: TextStyle(fontSize: 15),
                                inputFormatters: [
                                  FilteringTextInputFormatter.digitsOnly,
                                  LengthLimitingTextInputFormatter(10),
                                ],
                                validator: (value) {
                                  if (value.trimRight().trimLeft().isEmpty) {
                                    return 'Please enter your number';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  formData['number'] =
                                      value.trimLeft().trimRight();
                                },
                                decoration: InputDecoration(
                                  prefixIcon: Icon(
                                    Icons.call,
                                    color: buttonCOlor,
                                  ),
                                  errorStyle: TextStyle(
                                      // color: whiteTextColor,
                                      ),
                                  hintText: 'Enter your 10 digit phone number',
                                  hintStyle: TextStyle(color: textColor1),
                                  contentPadding: EdgeInsets.fromLTRB(
                                      20.0, 15.0, 20.0, 15.0),
                                  isDense: true,
                                  // hintStyle:
                                  //     normalStyle.copyWith(color: Colors.white),
                                  // enabledBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: Colors.white),
                                  // ),
                                  // focusedBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: whiteTextColor),
                                  // ),
                                )),
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Email*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: TextFormField(
                                autocorrect: true,
                                keyboardType: TextInputType.emailAddress,
                                style: TextStyle(fontSize: 15),
                                validator: (value) {
                                  bool emailValid = RegExp(
                                          r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                      .hasMatch(value.trimRight().trimLeft());
                                  if (value.trimRight().trimLeft().isEmpty) {
                                    return 'Please enter your email';
                                  }
                                  if (!emailValid) {
                                    return 'Invalid email!';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  formData['email'] =
                                      value.trimLeft().trimRight();
                                },
                                decoration: InputDecoration(
                                  prefixIcon: Icon(
                                    Icons.email,
                                    color: buttonCOlor,
                                  ),
                                  errorStyle: TextStyle(
                                      // color: whiteTextColor,
                                      ),
                                  hintText: 'Your email goes here',
                                  hintStyle: TextStyle(color: textColor1),
                                  contentPadding: EdgeInsets.fromLTRB(
                                      20.0, 15.0, 20.0, 15.0),
                                  isDense: true,
                                  // hintStyle:
                                  //     normalStyle.copyWith(color: Colors.white),
                                  // enabledBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: Colors.white),
                                  // ),
                                  // focusedBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: whiteTextColor),
                                  // ),
                                )),
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Gender*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Row(
                            children: <Widget>[
                              Expanded(
                                flex: 1,
                                child: RadioListTile(
                                  value: 0,
                                  groupValue: _groupValue,
                                  title: Text("Male"),
                                  onChanged: (newValue) =>
                                      setState(() => _groupValue = newValue),
                                  activeColor: buttonCOlor,
                                  selected: false,
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: RadioListTile(
                                  value: 1,
                                  groupValue: _groupValue,
                                  title: Text("Female"),
                                  onChanged: (newValue) =>
                                      setState(() => _groupValue = newValue),
                                  activeColor: buttonCOlor,
                                  selected: false,
                                ),
                              ),
                            ],
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Pasword*',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: TextFormField(
                                obscureText: !this._showPassword,
                                // keyboardType: TextInputType.visiblePassword,
                                autocorrect: true,
                                style: TextStyle(fontSize: 15),
                                validator: (value) {
                                  if (value.trimRight().trimLeft().isEmpty) {
                                    return 'Please enter your password';
                                  }
                                  if (value.length > 20) {
                                    return 'Password should be max 20 characters!';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  formData['password'] =
                                      value.trimLeft().trimRight();
                                },
                                decoration: InputDecoration(
                                  prefixIcon: Icon(
                                    Icons.lock,
                                    color: buttonCOlor,
                                  ),
                                  suffixIcon: IconButton(
                                    iconSize: 30,
                                    icon: Icon(
                                      Icons.visibility_off,
                                      color: this._showPassword
                                          ? Colors.grey
                                          : buttonCOlor,
                                    ),
                                    onPressed: () {
                                      setState(() => this._showPassword =
                                          !this._showPassword);
                                    },
                                  ),
                                  errorStyle: TextStyle(
                                      // color: whiteTextColor,
                                      ),
                                  hintText: 'Password',
                                  hintStyle: TextStyle(color: textColor1),
                                  contentPadding: EdgeInsets.fromLTRB(
                                      20.0, 15.0, 20.0, 15.0),
                                  isDense: true,
                                  // hintStyle:
                                  //     normalStyle.copyWith(color: Colors.white),
                                  // enabledBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: Colors.white),
                                  // ),
                                  // focusedBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: whiteTextColor),
                                  // ),
                                )),
                          ),
                          buildSizedBoxHeight(20),
                          Text(
                            'Confirm Password',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          buildSizedBoxHeight(10),
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(color: textColor)),
                            child: TextFormField(
                                obscureText: this._showPassword,
                                autocorrect: true,
                                style: TextStyle(fontSize: 15),
                                validator: (value) {
                                  if (value.trimRight().trimLeft().isEmpty) {
                                    return 'Please enter your password';
                                  }
                                  if (value.length > 20) {
                                    return 'Password should be max 20 characters!';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  formData['password'] =
                                      value.trimLeft().trimRight();
                                },
                                decoration: InputDecoration(
                                  prefixIcon: Icon(
                                    Icons.lock,
                                    color: buttonCOlor,
                                  ),
                                  errorStyle: TextStyle(
                                      // color: whiteTextColor,
                                      ),
                                  hintText: 'Password',
                                  hintStyle: TextStyle(color: textColor1),
                                  contentPadding: EdgeInsets.fromLTRB(
                                      20.0, 15.0, 20.0, 15.0),
                                  isDense: true,
                                  // hintStyle:
                                  //     normalStyle.copyWith(color: Colors.white),
                                  // enabledBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: Colors.white),
                                  // ),
                                  // focusedBorder: UnderlineInputBorder(
                                  //   borderSide: BorderSide(color: whiteTextColor),
                                  // ),
                                )),
                          ),
                          buildSizedBoxHeight(20),
                          Container(
                            height: 45,
                            width: buildWidth(context) / 1.1,
                            child: RaisedButton(
                                color: buttonCOlor,
                                onPressed: () {
                                  Navigator.pushReplacement(
                                      context,
                                      FadeNavigation(
                                          widget: ProfessionalInfo()));
                                },
                                child: Text("Next",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ))),
                          ),
                          buildSizedBoxHeight(10),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
