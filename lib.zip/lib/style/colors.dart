import 'package:flutter/material.dart';

const Color buttonCOlor = Colors.deepPurple;
const Color textColor = Colors.black;
const Color textColor1 = Colors.grey;
